package enums;

public enum FoodSize {
SMALL,
MEDIUM,
LARGE
}
