package enums;

public enum OrderStatus {
PAID,
UNPAID,
DELIVERING,
SIGNED_FOR,
CANCELLED
}
