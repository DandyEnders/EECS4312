package enums;

public enum UserPosition {
CLIENT,
MANAGER,
SYSTEM
}
